#include <stdio.h>
#include "fs.h"

void FileSysInit(void)
{

}
void SetInodeBitmap(int blkno)
{

}


void ResetInodeBitmap(int blkno)
{

}


void SetBlockBitmap(int blkno)
{

}


void ResetBlockBitmap(int blkno)
{

}


void PutInode(int blkno, Inode* pInode)
{

}


void GetInode(int blkno, Inode* pInode)
{

}


int GetFreeInodeNum(void)
{

}


int GetFreeBlockNum(void)
{

}






